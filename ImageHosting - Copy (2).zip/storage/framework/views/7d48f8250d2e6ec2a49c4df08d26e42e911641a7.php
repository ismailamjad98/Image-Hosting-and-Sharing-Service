<?php echo e($slot); ?>

<?php /**PATH E:\socialcamp - Copy\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>