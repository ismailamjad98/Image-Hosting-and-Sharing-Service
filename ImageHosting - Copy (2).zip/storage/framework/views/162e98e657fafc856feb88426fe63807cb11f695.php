<html>

Welcome to SocialCamp. Please click on the Button to Change your password <br><br>

<Button style="background-color: green; padding: 10px;"><a href="<?php echo e($url); ?>" style="color: white;"> Click to varify </a></Button><br><br>
Thank You,<br>
Image Hosting</p>
</html><?php /**PATH E:\ImageHosting\resources\views/forget_password.blade.php ENDPATH**/ ?>