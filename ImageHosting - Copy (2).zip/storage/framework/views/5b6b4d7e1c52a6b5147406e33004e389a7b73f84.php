<html>

Welcome to SocialCamp. Please Verify Your Email <br><br>

<Button style="background-color: red; padding: 10px;"><a href="<?php echo e($url); ?>" style="color: white;"> Click to varify </a></Button><br><br>
Thank You,<br>
SocialCamp</p>
</html><?php /**PATH C:\xampp\htdocs\socialcamp\resources\views/welcome_email.blade.php ENDPATH**/ ?>