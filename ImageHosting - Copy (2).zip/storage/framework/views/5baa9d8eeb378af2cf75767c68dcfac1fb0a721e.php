<html>

Welcome to SocialCamp. Please Verify Your Email <br><br>

<Button style="background-color: green; padding: 10px;"><a href="<?php echo e($url); ?>" style="color: white;"> Click to varify </a></Button><br><br>
Thank You,<br>
Image Hosting</p>
</html><?php /**PATH E:\ImageHosting\resources\views/welcome_email.blade.php ENDPATH**/ ?>