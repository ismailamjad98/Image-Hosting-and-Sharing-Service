<html>

Welcome to SocialCamp. Please Verify Your Email <br><br>

<Button style="background-color: green; padding: 10px;"><a href="{{ $url }}" style="color: white;"> Click to varify </a></Button><br><br>
Thank You,<br>
Image Hosting</p>
</html>