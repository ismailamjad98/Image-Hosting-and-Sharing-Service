<?php

return [
    'key' => env('JWT_TOKEN')
];