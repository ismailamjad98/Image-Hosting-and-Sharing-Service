<?php

return[

    'key' => env('JWT_TOKEN'),
    'code' => env('CODE'),
];
